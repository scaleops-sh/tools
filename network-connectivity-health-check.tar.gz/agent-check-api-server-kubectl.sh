agent_pod=$(kubectl get pod -lapp.kubernetes.io/name=scaleops-agent --no-headers -o=custom-columns=NAME:.metadata.name)
kubectl cp ~/github/eyal-stuff/scaleops/sheep/install-kubectl.sh $agent_pod:/
kubectl exec deploy/scaleops-agent -- sh -c "/install-kubectl.sh"

kubectl exec deploy/scaleops-agent -- kubectl get pod
