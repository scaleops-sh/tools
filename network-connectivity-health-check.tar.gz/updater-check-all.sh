echo Updater
echo -------
./updater-check-prometheus-ingress.sh
./updater-check-prometheus-egress.sh
./updater-check-api-server.sh
./updater-check-dns.sh
./updater-check-internet.sh
