tar -zcvf network-connectivity-health-check.tar.gz .
