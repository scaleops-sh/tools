admissions_pod=$(kubectl get pod -lapp.kubernetes.io/name=scaleops-admissions --no-headers -o=custom-columns=NAME:.metadata.name)
kubectl cp ~/github/eyal-stuff/scaleops/sheep/install-kubectl.sh $admissions_pod:/
kubectl exec deploy/scaleops-admissions -- sh -c "/install-kubectl.sh"

kubectl exec deploy/scaleops-admissions -- kubectl get pod
