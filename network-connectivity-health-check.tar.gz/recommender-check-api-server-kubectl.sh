recommender_pod=$(kubectl get pod -lapp.kubernetes.io/name=scaleops-recommender --no-headers -o=custom-columns=NAME:.metadata.name)
kubectl cp ~/github/eyal-stuff/scaleops/sheep/install-kubectl.sh $recommender_pod:/
kubectl exec deploy/scaleops-recommender -- sh -c "/install-kubectl.sh"

kubectl exec deploy/scaleops-recommender -- kubectl get pod
