kubectl exec deploy/scaleops-updater -- sh -c 'wget http://$KUBERNETES_SERVICE_HOST:$KUBERNETES_SERVICE_PORT -T 2'
