kubectl exec deploy/scaleops-prometheus-server -c prometheus-server -- wget scaleops-agent:8080/metrics -T 2 --spider 2>/dev/null
exit_code=$?
printf "Prometheus->Agent: "
if [ "$exit_code" == "0" ]; then
  echo WORKS
else
  echo FAILED
fi