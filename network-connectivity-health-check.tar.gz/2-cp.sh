cp network-connectivity-health-check.tar.gz /Users/eyalzilberberg/github/tools
