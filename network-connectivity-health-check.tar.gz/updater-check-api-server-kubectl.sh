updater_pod=$(kubectl get pod -lapp.kubernetes.io/name=scaleops-updater --no-headers -o=custom-columns=NAME:.metadata.name)
kubectl cp ~/github/eyal-stuff/scaleops/sheep/install-kubectl.sh $updater_pod:/
kubectl exec deploy/scaleops-updater -- sh -c "/install-kubectl.sh"

kubectl exec deploy/scaleops-updater -- kubectl get pod
