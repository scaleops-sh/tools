kubectl create -f healthcheck-pod.yaml
