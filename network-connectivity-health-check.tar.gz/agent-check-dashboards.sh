kubectl exec deploy/scaleops-agent -- wget http://scaleops-dashboards:8080 -T 2 --spider 2>/dev/null
exit_code=$?
printf "Agent->Dashboard: "
if [ "$exit_code" == "0" ]; then
  echo WORKS
else
  echo FAILED
fi

