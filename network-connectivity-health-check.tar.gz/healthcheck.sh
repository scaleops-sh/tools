cd $p
./_create-healthcheck-pod.sh
./_check-healthcheck.sh
./_delete-healthcheck-pod.sh
