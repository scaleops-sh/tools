kubectl exec deploy/scaleops-dashboards -- wget 172.253.116.99 -T 2 --spider 2>/dev/null
exit_code=$?
printf "Dashboards->Internet disconnected: "
if [ "$exit_code" == "0" ]; then
  echo FAILED
else
  echo WORKS
fi

