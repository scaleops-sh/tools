echo Prometheus
echo ----------
./prometheus-check-agent-ingress.sh
./prometheus-check-dashboards-ingress.sh
./prometheus-check-recommender-ingress.sh
./prometheus-check-updater-ingress.sh
./prometheus-check-api-server.sh
./prometheus-check-dns.sh
./prometheus-check-ksm-egress.sh
./prometheus-check-agent-egress.sh
./prometheus-check-recommender-egress.sh
./prometheus-check-updater-egress.sh
./prometheus-check-internet.sh