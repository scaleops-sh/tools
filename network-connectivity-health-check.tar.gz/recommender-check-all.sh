echo Recommender
echo -----------
./recommender-check-prometheus-ingress.sh
./recommender-check-prometheus-egress.sh
./recommender-check-api-server.sh
./recommender-check-dns.sh
./recommender-check-dashboards.sh
./recommender-check-internet.sh