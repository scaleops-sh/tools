kubectl delete pod scaleops-healthcheck
