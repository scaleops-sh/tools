echo Agent
echo -----
./agent-check-prometheus-ingress.sh
./agent-check-prometheus-egress.sh
./agent-check-api-server.sh
./agent-check-dns.sh
./agent-check-dashboards.sh
./agent-check-repo-updater.sh
./agent-check-internet.sh
