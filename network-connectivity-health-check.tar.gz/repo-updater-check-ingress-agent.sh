ret=$(kubectl exec deploy/scaleops-agent -- wget http://scaleops-repo-updater:81 -T 2 --spider 2>&1)
printf "Agent->Repo Updater: "
if [[ "$ret" == *"Connection reset by peer"* ]]; then
  echo WORKS
else
  echo FAILED
fi
