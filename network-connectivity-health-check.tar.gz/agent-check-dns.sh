ret=$(kubectl exec deploy/scaleops-agent -- nslookup scaleops-prometheus-server 2>&1)
printf "Agent->DNS: "
if [[ "$ret" == *"timed"* ]]; then
  echo FAILED
else
  echo WORKS
fi