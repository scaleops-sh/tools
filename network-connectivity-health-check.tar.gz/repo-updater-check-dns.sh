ret=$(kubectl exec deploy/scaleops-repo-updater -- nslookup scaleops-prometheus-server 2>&1)
printf "Dashboard->DNS: "
if [[ "$ret" == *"timed"* ]]; then
  echo FAILED
else
  echo WORKS
fi
