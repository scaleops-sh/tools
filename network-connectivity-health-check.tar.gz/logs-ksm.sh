kubectl logs -n scaleops-system deploy/scaleops-kube-state-metrics
