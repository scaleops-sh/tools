./logs-ksm.sh | grep "an error on the server" -q
exit_code=$?
printf "KSM->API Server: "
if [ "$exit_code" == "0" ]; then
  echo FAILED
else
  echo WORKS
fi
