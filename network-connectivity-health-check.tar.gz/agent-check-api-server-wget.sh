kubectl exec deploy/scaleops-agent -- sh -c 'wget http://$KUBERNETES_SERVICE_HOST:$KUBERNETES_SERVICE_PORT -T 2'
