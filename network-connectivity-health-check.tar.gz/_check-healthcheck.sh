kubectl get pod scaleops-healthcheck -oyaml | grep scaleops.sh/healthcheck -q
exit_code="$?"
if [ "$exit_code" == 0 ]; then
  echo admission health check PASSED
else
  echo admission health check FAILED
fi
