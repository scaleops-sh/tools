echo KSM
echo ---
./ksm-check-api-server.sh
./ksm-check-prometheus-ingress.sh
