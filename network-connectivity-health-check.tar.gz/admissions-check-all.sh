echo Admissions
echo ----------
./admissions-check-api-server-ingress.sh
./admissions-check-api-server.sh
./admissions-check-internet.sh
