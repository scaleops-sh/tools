res=$(healthcheck.sh)
printf "API Server->Admissions: "
if [[ "$res" == *"PASSED"* ]]; then
  echo WORKS
else
  echo FAILED
fi
