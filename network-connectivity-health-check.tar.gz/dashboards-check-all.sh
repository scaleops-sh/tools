echo Dashboards
echo ----------
./dashboards-check-agent.sh
./dashboards-check-recommender.sh
./dashboards-check-api-server.sh
./dashboards-check-dns.sh
./dashboards-check-prometheus-egress.sh
./dashboards-check-repo-updater.sh
./dashboards-check-internet.sh