echo Repo Updater
echo ------------
./repo-updater-check-ingress-agent.sh
./repo-updater-check-ingress-dashboards.sh
./repo-updater-check-api-server.sh
./repo-updater-check-dns.sh
./repo-updater-check-internet.sh
