ret=$(kubectl exec deploy/scaleops-dashboards -- nslookup scaleops-prometheus-server 2>&1)
printf "Dashboard->DNS: "
if [[ "$ret" == *"timed"* ]]; then
  echo FAILED
else
  echo WORKS
fi
