ret=$(kubectl exec deploy/scaleops-updater -- nslookup scaleops-prometheus-server 2>&1)
printf "Updater->DNS: "
if [[ "$ret" == *"timed"* ]]; then
  echo FAILED
else
  echo WORKS
fi
