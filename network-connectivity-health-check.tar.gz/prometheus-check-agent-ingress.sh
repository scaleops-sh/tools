kubectl exec deploy/scaleops-agent -- wget http://scaleops-prometheus-server -T 2 --spider 2>/dev/null
exit_code=$?
printf "Agent->Prometheus: "
if [ "$exit_code" == "0" ]; then
  echo WORKS
else
  echo FAILED
fi
