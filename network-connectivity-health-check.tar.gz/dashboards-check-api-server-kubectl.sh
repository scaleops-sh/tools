dashboards_pod=$(kubectl get pod -lapp.kubernetes.io/name=scaleops-dashboards --no-headers -o=custom-columns=NAME:.metadata.name)
kubectl cp ~/github/eyal-stuff/scaleops/sheep/install-kubectl.sh $dashboards_pod:/
kubectl exec deploy/scaleops-dashboards -- sh -c "/install-kubectl.sh"

kubectl exec deploy/scaleops-dashboards -- kubectl get pod
