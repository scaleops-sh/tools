ret=$(kubectl exec deploy/scaleops-prometheus-server -- sh -c 'wget http://$KUBERNETES_SERVICE_HOST:$KUBERNETES_SERVICE_PORT -T 2' 2>&1)
printf "Prometheus->API Server: "
if [[ "$ret" == *"timed"* ]]; then
  echo FAILED
else
  echo WORKS
fi
