./admissions-check-all.sh
./agent-check-all.sh
./dashboards-check-all.sh
./recommender-check-all.sh
./updater-check-all.sh
./ksm-check-all.sh
./prometheus-check-all.sh
./repo-updater-check-all.sh
